package com.example.operaciones;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView result;
    private TextView num1;
    private TextView  num2;
     private  int valor1 = 10;
     private  int valor2 = 5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        result = findViewById(R.id.result);
        num1= findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        num1.setText(String.valueOf(valor1));
        num2.setText(String.valueOf(valor2));
    }

    public void sumar(View view) {
        int suma = valor1 + valor2;
        result.setText("Resultado: " + suma);
    }

    public void restar(View view) {
        int resta = valor1 - valor2;
        result.setText("Resultado: " + resta);
    }

    public void multiplicar(View view) {
        int multiplicacion = valor1 * valor2;
        result.setText("Resultado: " + multiplicacion);
    }

    public void dividir(View view) {
        int division = valor1/ valor2;
        result.setText("Resultado: " + division);

    }
}